# Ibe · Presupuestos

Web para generar y guardar presupuestos de reformas y obras, organizados por carpetas de cliente, con generación asistida de partidas a partir de texto o voz.

## Poner en marcha en tu ordenador

```bash
npm install
npm run dev
```

Abre la dirección que te indique la terminal (normalmente http://localhost:5173).

## Publicar la web (gratis)

La forma más sencilla es con **Vercel** o **Netlify**:
1. Sube este proyecto a GitHub (ver más abajo).
2. Entra en vercel.com o netlify.com, inicia sesión con tu cuenta de GitHub.
3. Elige "Importar proyecto" y selecciona este repositorio.
4. Déjalo con la configuración por defecto (detectan Vite solos) y pulsa "Deploy".

En unos minutos tendrás una URL pública.

## Nota sobre el guardado de datos

Ahora mismo los clientes y presupuestos se guardan en el propio navegador (`localStorage`). Esto significa que los datos solo están disponibles en ese ordenador/navegador concreto, y se perderían si borras los datos de navegación.

Para tener una base de datos real (acceso desde el móvil, desde el ordenador de la oficina, con copias de seguridad, etc.) haría falta conectar un backend, por ejemplo Supabase o Firebase. Es el siguiente paso natural si la aplicación empieza a usarse en el día a día.
