import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  Hammer, FolderOpen, Folder, Plus, Trash2, Mic, MicOff, Save,
  Search, X, ChevronRight, FileText, Phone, MapPin, Printer,
  AlertTriangle, CheckCircle2, Clock, Ruler
} from "lucide-react";

/* ---------------------------------------------------------------
   CATÁLOGO DE PARTIDAS — precios base de referencia (orden de obra)
   Cada partida tiene palabras clave para reconocerla en el texto
   libre o dictado del albañil.
--------------------------------------------------------------- */
const CATALOGO = [
  { key: "escombros", orden: 1, desc: "Retirada de escombros y contenedor", unidad: "ud", base: 280, tipo: "fijo",
    kw: ["escombro", "contenedor", "retirada de escombro"] },
  { key: "demolicion", orden: 2, desc: "Demolición de tabiquería / elementos existentes", unidad: "m²", base: 16, tipo: "m2",
    kw: ["demoler", "demolicion", "demolición", "derribo", "tirar tabique", "picar alicatado", "quitar suelo"] },
  { key: "fontaneria", orden: 3, desc: "Instalación de fontanería (agua y desagües)", unidad: "m²", base: 42, tipo: "m2",
    kw: ["fontaneria", "fontanería", "tuberia", "tuberías", "desague", "desagüe", "agua fria", "agua caliente"] },
  { key: "electricidad", orden: 4, desc: "Instalación eléctrica (cableado y mecanismos)", unidad: "m²", base: 38, tipo: "m2",
    kw: ["electricidad", "electrica", "eléctrica", "cableado", "enchufe", "instalacion electrica"] },
  { key: "cuadro_electrico", orden: 5, desc: "Sustitución de cuadro eléctrico general", unidad: "ud", base: 380, tipo: "fijo",
    kw: ["cuadro electrico", "cuadro eléctrico", "cuadro general"] },
  { key: "tabiqueria", orden: 6, desc: "Tabiquería de pladur / distribución interior", unidad: "m²", base: 34, tipo: "m2",
    kw: ["tabique", "pladur", "tabiqueria", "tabiquería", "division", "división"] },
  { key: "enlucido", orden: 7, desc: "Enfoscado y enlucido de paredes", unidad: "m²", base: 13, tipo: "m2",
    kw: ["enlucido", "enfoscado", "guarnecido", "yeso"] },
  { key: "alicatado", orden: 8, desc: "Alicatado de paredes con azulejo", unidad: "m²", base: 39, tipo: "m2",
    kw: ["alicatado", "azulejo", "alicatar"] },
  { key: "solado", orden: 9, desc: "Solado / colocación de pavimento", unidad: "m²", base: 33, tipo: "m2",
    kw: ["solado", "suelo", "pavimento", "baldosa", "parquet", "tarima"] },
  { key: "sanitarios", orden: 10, desc: "Suministro y colocación de sanitarios", unidad: "ud", base: 190, tipo: "fijo",
    kw: ["inodoro", "lavabo", "bañera", "banera", "ducha", "plato de ducha", "sanitario"] },
  { key: "carpinteria", orden: 11, desc: "Carpintería (puertas y/o ventanas)", unidad: "ud", base: 260, tipo: "fijo",
    kw: ["puerta", "ventana", "carpinteria", "carpintería"] },
  { key: "pintura", orden: 12, desc: "Pintura de paredes y techos", unidad: "m²", base: 9, tipo: "m2",
    kw: ["pintura", "pintar", "pintado"] },
];

const IVA_OPCIONES = [
  { label: "21% (general)", value: 21 },
  { label: "10% (rehabilitación vivienda)", value: 10 },
  { label: "4% (reducido)", value: 4 },
  { label: "0% (exento)", value: 0 },
];

const ESTADOS = {
  borrador: { label: "BORRADOR", color: "#9C9A8E" },
  enviado: { label: "ENVIADO", color: "#3E6990" },
  aceptado: { label: "ACEPTADO", color: "#6E8F5C" },
};

/* Almacenamiento local del navegador (independiente, sin backend).
   Para guardar los datos en una base de datos real y accesible desde
   varios dispositivos, esto habría que sustituirlo por llamadas a un
   backend (por ejemplo Supabase, Firebase, o una API propia). */
const storage = {
  async get(key) {
    const v = localStorage.getItem(key);
    return v == null ? null : { key, value: v };
  },
  async set(key, value) {
    localStorage.setItem(key, value);
    return { key, value };
  },
};

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
const norm = (s) => (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
const eur = (n) => (Math.round((n || 0) * 100) / 100).toLocaleString("es-ES", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/* ---------------------------------------------------------------
   Reconoce partidas dentro de un texto libre (escrito o dictado)
--------------------------------------------------------------- */
function detectarPartidas(texto, m2, precios) {
  const t = norm(texto);
  const encontradas = [];
  CATALOGO.forEach((c) => {
    const match = c.kw.some((k) => t.includes(norm(k)));
    if (match) {
      const precioAprendido = precios[c.key];
      const precioUnit = precioAprendido != null ? precioAprendido : c.base;
      const cantidad = c.tipo === "m2" ? (Number(m2) || 1) : 1;
      encontradas.push({
        id: uid(),
        key: c.key,
        orden: c.orden,
        desc: c.desc,
        unidad: c.unidad,
        cantidad,
        precioUnit,
      });
    }
  });
  return encontradas.sort((a, b) => a.orden - b.orden);
}

/* ---------------------------------------------------------------
   Componente principal
--------------------------------------------------------------- */
export default function App() {
  const [clientes, setClientes] = useState(null);
  const [presupuestos, setPresupuestos] = useState(null);
  const [precios, setPrecios] = useState({});
  const [loading, setLoading] = useState(true);
  const [errorStorage, setErrorStorage] = useState(false);

  const [clienteSelId, setClienteSelId] = useState(null);
  const [presupuestoSelId, setPresupuestoSelId] = useState(null);
  const [busqueda, setBusqueda] = useState("");
  const [nuevoClienteAbierto, setNuevoClienteAbierto] = useState(false);
  const [formCliente, setFormCliente] = useState({ nombre: "", telefono: "", direccion: "" });

  const [borrador, setBorrador] = useState(null); // presupuesto en edición
  const [textoTareas, setTextoTareas] = useState("");
  const [grabando, setGrabando] = useState(false);
  const reconocimientoRef = useRef(null);
  const [avisoGuardado, setAvisoGuardado] = useState("");

  /* ---------- Carga inicial desde almacenamiento persistente ---------- */
  useEffect(() => {
    (async () => {
      try {
        const [c, p, pr] = await Promise.allSettled([
          storage.get("clientes"),
          storage.get("presupuestos"),
          storage.get("precios_aprendidos"),
        ]);
        setClientes(c.status === "fulfilled" && c.value ? JSON.parse(c.value.value) : []);
        setPresupuestos(p.status === "fulfilled" && p.value ? JSON.parse(p.value.value) : []);
        setPrecios(pr.status === "fulfilled" && pr.value ? JSON.parse(pr.value.value) : {});
      } catch (e) {
        console.error(e);
        setErrorStorage(true);
        setClientes([]);
        setPresupuestos([]);
        setPrecios({});
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const persistClientes = useCallback(async (data) => {
    setClientes(data);
    try { await storage.set("clientes", JSON.stringify(data)); } catch (e) { console.error(e); }
  }, []);
  const persistPresupuestos = useCallback(async (data) => {
    setPresupuestos(data);
    try { await storage.set("presupuestos", JSON.stringify(data)); } catch (e) { console.error(e); }
  }, []);
  const persistPrecios = useCallback(async (data) => {
    setPrecios(data);
    try { await storage.set("precios_aprendidos", JSON.stringify(data)); } catch (e) { console.error(e); }
  }, []);

  /* ---------- Clientes ---------- */
  const crearCliente = async () => {
    if (!formCliente.nombre.trim()) return;
    const nuevo = { id: uid(), ...formCliente, createdAt: Date.now() };
    await persistClientes([nuevo, ...clientes]);
    setFormCliente({ nombre: "", telefono: "", direccion: "" });
    setNuevoClienteAbierto(false);
    setClienteSelId(nuevo.id);
  };

  const eliminarCliente = async (id) => {
    await persistClientes(clientes.filter((c) => c.id !== id));
    await persistPresupuestos(presupuestos.filter((p) => p.clientId !== id));
    if (clienteSelId === id) { setClienteSelId(null); setPresupuestoSelId(null); setBorrador(null); }
  };

  /* ---------- Presupuestos ---------- */
  const iniciarNuevoPresupuesto = () => {
    setPresupuestoSelId(null);
    setTextoTareas("");
    setBorrador({
      id: uid(),
      clientId: clienteSelId,
      titulo: "",
      ubicacion: "habitación",
      m2: "",
      iva: 21,
      items: [],
      estado: "borrador",
      createdAt: Date.now(),
    });
  };

  const abrirPresupuesto = (p) => {
    setPresupuestoSelId(p.id);
    setBorrador({ ...p, items: p.items.map((it) => ({ ...it })) });
    setTextoTareas("");
  };

  const generarPartidas = () => {
    if (!textoTareas.trim()) return;
    const nuevas = detectarPartidas(textoTareas, borrador.m2, precios);
    setBorrador((b) => {
      const existentes = new Set(b.items.map((i) => i.key));
      const combinadas = [...b.items, ...nuevas.filter((n) => !existentes.has(n.key))];
      combinadas.sort((a, c) => a.orden - c.orden);
      return { ...b, items: combinadas };
    });
    setTextoTareas("");
  };

  const actualizarItem = (id, campo, valor) => {
    setBorrador((b) => ({
      ...b,
      items: b.items.map((it) => (it.id === id ? { ...it, [campo]: valor } : it)),
    }));
  };

  // El albañil corrige un precio -> a partir de ahora ese es el precio "aprendido"
  const confirmarPrecioAlbanil = async (item) => {
    const nuevosPrecios = { ...precios, [item.key]: Number(item.precioUnit) || 0 };
    await persistPrecios(nuevosPrecios);
  };

  const eliminarItem = (id) => {
    setBorrador((b) => ({ ...b, items: b.items.filter((it) => it.id !== id) }));
  };

  const totales = (() => {
    if (!borrador) return { base: 0, iva: 0, total: 0 };
    const base = borrador.items.reduce((s, it) => s + (Number(it.cantidad) || 0) * (Number(it.precioUnit) || 0), 0);
    const iva = base * ((Number(borrador.iva) || 0) / 100);
    return { base, iva, total: base + iva };
  })();

  const guardarPresupuesto = async () => {
    if (!borrador) return;
    const actualizado = { ...borrador, updatedAt: Date.now() };
    const existe = presupuestos.some((p) => p.id === actualizado.id);
    const lista = existe
      ? presupuestos.map((p) => (p.id === actualizado.id ? actualizado : p))
      : [actualizado, ...presupuestos];
    await persistPresupuestos(lista);
    setPresupuestoSelId(actualizado.id);
    setAvisoGuardado("Presupuesto guardado");
    setTimeout(() => setAvisoGuardado(""), 2200);
  };

  const eliminarPresupuesto = async (id) => {
    await persistPresupuestos(presupuestos.filter((p) => p.id !== id));
    if (presupuestoSelId === id) { setPresupuestoSelId(null); setBorrador(null); }
  };

  /* ---------- Dictado por voz ---------- */
  const toggleGrabacion = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { alert("Este navegador no soporta el dictado por voz. Puedes escribir el texto directamente."); return; }
    if (grabando) {
      reconocimientoRef.current && reconocimientoRef.current.stop();
      setGrabando(false);
      return;
    }
    const rec = new SR();
    rec.lang = "es-ES";
    rec.continuous = true;
    rec.interimResults = false;
    rec.onresult = (e) => {
      let texto = "";
      for (let i = e.resultIndex; i < e.results.length; i++) texto += e.results[i][0].transcript + " ";
      setTextoTareas((t) => (t ? t + " " + texto : texto));
    };
    rec.onerror = () => setGrabando(false);
    rec.onend = () => setGrabando(false);
    reconocimientoRef.current = rec;
    rec.start();
    setGrabando(true);
  };

  /* ---------- Derivados de UI ---------- */
  const clientesFiltrados = (clientes || []).filter((c) =>
    norm(c.nombre).includes(norm(busqueda))
  );
  const clienteSel = (clientes || []).find((c) => c.id === clienteSelId) || null;
  const presupuestosCliente = (presupuestos || []).filter((p) => p.clientId === clienteSelId)
    .sort((a, b) => (b.updatedAt || b.createdAt) - (a.updatedAt || a.createdAt));

  if (loading) {
    return (
      <div style={{ ...S.app, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color: T.muted, fontFamily: F.body }}>Cargando…</div>
      </div>
    );
  }

  return (
    <div style={S.app}>
      <style>{FONT_IMPORT}</style>
      {errorStorage && (
        <div style={S.bannerError}>
          <AlertTriangle size={16} /> No se ha podido conectar con el almacenamiento. Los datos de esta sesión no se guardarán.
        </div>
      )}

      {/* ---------------- Cabecera ---------------- */}
      <header style={S.header}>
        <div style={S.headerLeft}>
          <div style={S.logoBox}><Hammer size={20} color={T.bg} /></div>
          <div>
            <div style={S.logoText}>IBE · PRESUPUESTOS</div>
            <div style={S.logoSub}>Reformas y obras</div>
          </div>
        </div>
        <div style={S.tapeDivider} />
      </header>

      <div style={S.body}>
        {/* ---------------- Columna clientes ---------------- */}
        <aside style={S.sidebar}>
          <div style={S.sidebarTop}>
            <div style={S.searchBox}>
              <Search size={15} color={T.muted} />
              <input
                placeholder="Buscar cliente…"
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
                style={S.searchInput}
              />
            </div>
            <button style={S.btnAmberSmall} onClick={() => setNuevoClienteAbierto((v) => !v)}>
              <Plus size={15} /> Cliente
            </button>
          </div>

          {nuevoClienteAbierto && (
            <div style={S.newClientBox}>
              <input style={S.input} placeholder="Nombre del cliente"
                value={formCliente.nombre} onChange={(e) => setFormCliente({ ...formCliente, nombre: e.target.value })} />
              <input style={S.input} placeholder="Teléfono"
                value={formCliente.telefono} onChange={(e) => setFormCliente({ ...formCliente, telefono: e.target.value })} />
              <input style={S.input} placeholder="Dirección / obra"
                value={formCliente.direccion} onChange={(e) => setFormCliente({ ...formCliente, direccion: e.target.value })} />
              <button style={S.btnAmberSmall} onClick={crearCliente}><Save size={14} /> Guardar cliente</button>
            </div>
          )}

          <div style={S.clientList}>
            {clientesFiltrados.length === 0 && (
              <div style={S.emptyHint}>Aún no hay clientes. Crea una carpeta para empezar.</div>
            )}
            {clientesFiltrados.map((c) => {
              const nBudgets = (presupuestos || []).filter((p) => p.clientId === c.id).length;
              const activo = c.id === clienteSelId;
              return (
                <div
                  key={c.id}
                  onClick={() => { setClienteSelId(c.id); setPresupuestoSelId(null); setBorrador(null); }}
                  style={{ ...S.clientRow, ...(activo ? S.clientRowActive : {}) }}
                >
                  {activo ? <FolderOpen size={16} color={T.amber} /> : <Folder size={16} color={T.muted} />}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={S.clientName}>{c.nombre}</div>
                    <div style={S.clientMeta}>{nBudgets} presupuesto{nBudgets !== 1 ? "s" : ""}</div>
                  </div>
                  <button
                    title="Eliminar cliente"
                    style={S.iconGhost}
                    onClick={(e) => { e.stopPropagation(); if (confirm(`¿Eliminar a ${c.nombre} y todos sus presupuestos?`)) eliminarCliente(c.id); }}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              );
            })}
          </div>
        </aside>

        {/* ---------------- Panel principal ---------------- */}
        <main style={S.main}>
          {!clienteSel && (
            <div style={S.placeholder}>
              <Ruler size={28} color={T.muted} />
              <div style={{ marginTop: 10 }}>Selecciona o crea un cliente para ver sus presupuestos.</div>
            </div>
          )}

          {clienteSel && !borrador && (
            <div>
              <div style={S.clientHeader}>
                <div>
                  <div style={S.h1}>{clienteSel.nombre}</div>
                  <div style={S.clientHeaderMeta}>
                    {clienteSel.telefono && <span><Phone size={13} /> {clienteSel.telefono}</span>}
                    {clienteSel.direccion && <span><MapPin size={13} /> {clienteSel.direccion}</span>}
                  </div>
                </div>
                <button style={S.btnAmber} onClick={iniciarNuevoPresupuesto}>
                  <Plus size={16} /> Nuevo presupuesto
                </button>
              </div>

              <div style={S.tapeDividerThin} />

              <div style={S.budgetGrid}>
                {presupuestosCliente.length === 0 && (
                  <div style={S.emptyHint}>Este cliente todavía no tiene presupuestos.</div>
                )}
                {presupuestosCliente.map((p) => {
                  const base = p.items.reduce((s, it) => s + it.cantidad * it.precioUnit, 0);
                  const total = base * (1 + p.iva / 100);
                  const est = ESTADOS[p.estado] || ESTADOS.borrador;
                  return (
                    <div key={p.id} style={S.budgetCard} onClick={() => abrirPresupuesto(p)}>
                      <div style={S.stamp(est.color)}>{est.label}</div>
                      <div style={S.budgetCardTitle}>{p.titulo || "Presupuesto sin título"}</div>
                      <div style={S.budgetCardMeta}>{p.ubicacion} · {p.m2 || "—"} m²</div>
                      <div style={S.budgetCardTotal}>{eur(total)} €</div>
                      <div style={S.budgetCardFoot}>
                        <span>{new Date(p.updatedAt || p.createdAt).toLocaleDateString("es-ES")}</span>
                        <Trash2 size={14} style={{ cursor: "pointer" }}
                          onClick={(e) => { e.stopPropagation(); if (confirm("¿Eliminar este presupuesto?")) eliminarPresupuesto(p.id); }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {clienteSel && borrador && (
            <div>
              <div style={S.clientHeader}>
                <button style={S.linkBack} onClick={() => { setBorrador(null); setPresupuestoSelId(null); }}>
                  <ChevronRight size={14} style={{ transform: "rotate(180deg)" }} /> {clienteSel.nombre}
                </button>
                <div style={{ display: "flex", gap: 8 }}>
                  <select style={S.selectSmall} value={borrador.estado}
                    onChange={(e) => setBorrador({ ...borrador, estado: e.target.value })}>
                    {Object.entries(ESTADOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                  </select>
                  <button style={S.btnGhost} onClick={() => window.print()}><Printer size={14} /> Imprimir</button>
                  <button style={S.btnAmber} onClick={guardarPresupuesto}><Save size={15} /> Guardar</button>
                </div>
              </div>

              {avisoGuardado && <div style={S.avisoOk}><CheckCircle2 size={14} /> {avisoGuardado}</div>}

              {/* Datos generales */}
              <div style={S.formRow}>
                <input style={{ ...S.input, flex: 2 }} placeholder="Título (p. ej. Reforma baño principal)"
                  value={borrador.titulo} onChange={(e) => setBorrador({ ...borrador, titulo: e.target.value })} />
                <select style={S.input} value={borrador.ubicacion}
                  onChange={(e) => setBorrador({ ...borrador, ubicacion: e.target.value })}>
                  {["habitación", "baño", "cocina", "local", "nave", "vivienda completa", "otro"].map((u) => (
                    <option key={u} value={u}>{u}</option>
                  ))}
                </select>
                <input style={{ ...S.input, width: 100 }} type="number" placeholder="m²"
                  value={borrador.m2} onChange={(e) => setBorrador({ ...borrador, m2: e.target.value })} />
                <select style={S.input} value={borrador.iva}
                  onChange={(e) => setBorrador({ ...borrador, iva: Number(e.target.value) })}>
                  {IVA_OPCIONES.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>

              {/* Entrada de tareas por texto o voz */}
              <div style={S.taskBox}>
                <textarea
                  style={S.textarea}
                  rows={3}
                  placeholder="Escribe o dicta lo que hay que hacer: p. ej. «hay que demoler el tabique, meter fontanería nueva, alicatar y poner suelo, y pintar al final»"
                  value={textoTareas}
                  onChange={(e) => setTextoTareas(e.target.value)}
                />
                <div style={S.taskBoxActions}>
                  <button
                    style={{ ...S.btnGhost, ...(grabando ? S.btnGhostActive : {}) }}
                    onClick={toggleGrabacion}
                  >
                    {grabando ? <MicOff size={15} /> : <Mic size={15} />} {grabando ? "Detener" : "Dictar"}
                  </button>
                  <button style={S.btnAmber} onClick={generarPartidas}>
                    <Hammer size={15} /> Generar partidas
                  </button>
                </div>
              </div>

              <div style={S.tapeDividerThin} />

              {/* Tabla de partidas */}
              <div style={S.tableWrap}>
                <table style={S.table}>
                  <thead>
                    <tr>
                      <th style={S.th}>#</th>
                      <th style={S.th}>Descripción del trabajo</th>
                      <th style={S.th}>Ud.</th>
                      <th style={S.th}>Cant.</th>
                      <th style={S.th}>Precio ud. (€)</th>
                      <th style={S.th}>Importe (€)</th>
                      <th style={S.th}></th>
                    </tr>
                  </thead>
                  <tbody>
                    {borrador.items.length === 0 && (
                      <tr><td colSpan={7} style={S.emptyRow}>Todavía no hay partidas. Escribe o dicta los trabajos y pulsa «Generar partidas».</td></tr>
                    )}
                    {borrador.items.map((it, idx) => {
                      const aprendido = precios[it.key] != null && Number(precios[it.key]) === Number(it.precioUnit);
                      return (
                        <tr key={it.id}>
                          <td style={S.tdNum}>{idx + 1}</td>
                          <td style={S.td}>
                            <input style={S.tdInput} value={it.desc}
                              onChange={(e) => actualizarItem(it.id, "desc", e.target.value)} />
                          </td>
                          <td style={S.tdCenter}>{it.unidad}</td>
                          <td style={S.tdCenter}>
                            <input style={S.tdInputNum} type="number" value={it.cantidad}
                              onChange={(e) => actualizarItem(it.id, "cantidad", e.target.value)} />
                          </td>
                          <td style={S.tdCenter}>
                            <input
                              style={{ ...S.tdInputNum, ...(aprendido ? S.tdInputLearned : {}) }}
                              type="number"
                              value={it.precioUnit}
                              onChange={(e) => actualizarItem(it.id, "precioUnit", e.target.value)}
                              onBlur={() => confirmarPrecioAlbanil(it)}
                              title={aprendido ? "Precio del albañil (memorizado)" : "Precio de referencia — edítalo y se memorizará"}
                            />
                          </td>
                          <td style={S.tdMono}>{eur((it.cantidad || 0) * (it.precioUnit || 0))}</td>
                          <td style={S.tdCenter}>
                            <Trash2 size={14} style={{ cursor: "pointer", color: T.muted }} onClick={() => eliminarItem(it.id)} />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div style={S.totalsBox}>
                <div style={S.totalsRow}><span>Base imponible</span><span style={S.mono}>{eur(totales.base)} €</span></div>
                <div style={S.totalsRow}><span>IVA ({borrador.iva}%)</span><span style={S.mono}>{eur(totales.iva)} €</span></div>
                <div style={{ ...S.totalsRow, ...S.totalsFinal }}><span>TOTAL</span><span style={S.mono}>{eur(totales.total)} €</span></div>
              </div>

              <div style={S.footNote}>
                <Clock size={12} /> Los precios en <span style={{ color: T.amber }}>ámbar</span> son los que el albañil ha fijado y se aplicarán por defecto en próximos presupuestos, por encima del precio de referencia del catálogo.
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   Tokens de diseño
--------------------------------------------------------------- */
const T = {
  bg: "#1A1C19",
  panel: "#21231F",
  panelAlt: "#282A24",
  border: "#3A3C34",
  text: "#EDEAE0",
  muted: "#9C9A8E",
  amber: "#E3A72E",
  blue: "#3E6990",
  green: "#6E8F5C",
  danger: "#C1502E",
};
const F = {
  display: "'Barlow Condensed', sans-serif",
  body: "'Work Sans', sans-serif",
  mono: "'IBM Plex Mono', monospace",
};
const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800&family=Work+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@500;600&display=swap');`;

const tapeStripe = `repeating-linear-gradient(135deg, ${T.amber} 0 10px, #1A1C19 10px 20px)`;

const S = {
  app: { minHeight: "100vh", background: T.bg, color: T.text, fontFamily: F.body },
  bannerError: { display: "flex", gap: 8, alignItems: "center", background: "#4A2A20", color: "#F0C9B8", padding: "8px 16px", fontSize: 13 },
  header: { padding: "18px 24px 0" },
  headerLeft: { display: "flex", alignItems: "center", gap: 12, marginBottom: 14 },
  logoBox: { width: 38, height: 38, background: T.amber, display: "flex", alignItems: "center", justifyContent: "center", borderRadius: 4 },
  logoText: { fontFamily: F.display, fontWeight: 800, fontSize: 22, letterSpacing: 1, lineHeight: 1 },
  logoSub: { fontSize: 12, color: T.muted, letterSpacing: 1 },
  tapeDivider: { height: 6, background: tapeStripe, opacity: 0.9 },
  tapeDividerThin: { height: 3, background: tapeStripe, opacity: 0.6, margin: "16px 0" },

  body: { display: "flex", minHeight: "calc(100vh - 60px)" },
  sidebar: { width: 300, borderRight: `1px solid ${T.border}`, padding: 16, display: "flex", flexDirection: "column", gap: 12 },
  sidebarTop: { display: "flex", gap: 8 },
  searchBox: { flex: 1, display: "flex", alignItems: "center", gap: 6, background: T.panel, border: `1px solid ${T.border}`, borderRadius: 6, padding: "7px 10px" },
  searchInput: { background: "transparent", border: "none", outline: "none", color: T.text, fontSize: 13, width: "100%", fontFamily: F.body },
  newClientBox: { display: "flex", flexDirection: "column", gap: 6, background: T.panel, border: `1px solid ${T.border}`, borderRadius: 6, padding: 10 },
  clientList: { display: "flex", flexDirection: "column", gap: 4, overflowY: "auto" },
  clientRow: { display: "flex", alignItems: "center", gap: 8, padding: "9px 10px", borderRadius: 6, cursor: "pointer", border: "1px solid transparent" },
  clientRowActive: { background: T.panel, borderColor: T.border },
  clientName: { fontSize: 14, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" },
  clientMeta: { fontSize: 11, color: T.muted },
  iconGhost: { background: "none", border: "none", color: T.muted, cursor: "pointer", padding: 4 },
  emptyHint: { color: T.muted, fontSize: 13, padding: "12px 4px", lineHeight: 1.5 },

  main: { flex: 1, padding: "20px 32px 60px", overflowY: "auto" },
  placeholder: { color: T.muted, textAlign: "center", marginTop: 100 },
  clientHeader: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 10 },
  h1: { fontFamily: F.display, fontWeight: 800, fontSize: 30, letterSpacing: 0.5 },
  clientHeaderMeta: { display: "flex", gap: 16, color: T.muted, fontSize: 13, marginTop: 4 },
  linkBack: { display: "flex", alignItems: "center", gap: 4, background: "none", border: "none", color: T.muted, cursor: "pointer", fontSize: 14, padding: 0 },

  budgetGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 14, marginTop: 4 },
  budgetCard: { background: T.panel, border: `1px solid ${T.border}`, borderRadius: 8, padding: 14, cursor: "pointer", position: "relative" },
  budgetCardTitle: { fontWeight: 600, fontSize: 15, marginTop: 18, marginBottom: 4 },
  budgetCardMeta: { fontSize: 12, color: T.muted, marginBottom: 10 },
  budgetCardTotal: { fontFamily: F.mono, fontSize: 18, color: T.amber, fontWeight: 600 },
  budgetCardFoot: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10, fontSize: 11, color: T.muted },
  stamp: (color) => ({
    position: "absolute", top: 10, right: 10, fontFamily: F.display, fontSize: 10, fontWeight: 700,
    letterSpacing: 1, color, border: `1.5px solid ${color}`, borderRadius: 3, padding: "2px 6px", transform: "rotate(-4deg)",
  }),

  formRow: { display: "flex", gap: 10, flexWrap: "wrap", marginTop: 18 },
  input: { background: T.panel, border: `1px solid ${T.border}`, borderRadius: 6, padding: "9px 10px", color: T.text, fontSize: 13, fontFamily: F.body, outline: "none" },
  selectSmall: { background: T.panel, border: `1px solid ${T.border}`, borderRadius: 6, padding: "6px 8px", color: T.text, fontSize: 12, fontFamily: F.body },

  taskBox: { marginTop: 16, background: T.panel, border: `1px solid ${T.border}`, borderRadius: 8, padding: 12 },
  textarea: { width: "100%", background: T.panelAlt, border: `1px solid ${T.border}`, borderRadius: 6, color: T.text, fontFamily: F.body, fontSize: 13, padding: 10, resize: "vertical", outline: "none", boxSizing: "border-box" },
  taskBoxActions: { display: "flex", gap: 8, marginTop: 10, justifyContent: "flex-end" },

  btnAmber: { display: "flex", alignItems: "center", gap: 6, background: T.amber, color: "#1A1C19", border: "none", borderRadius: 6, padding: "9px 14px", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: F.body },
  btnAmberSmall: { display: "flex", alignItems: "center", gap: 5, background: T.amber, color: "#1A1C19", border: "none", borderRadius: 6, padding: "7px 10px", fontWeight: 700, fontSize: 12, cursor: "pointer", fontFamily: F.body, whiteSpace: "nowrap" },
  btnGhost: { display: "flex", alignItems: "center", gap: 6, background: "transparent", color: T.text, border: `1px solid ${T.border}`, borderRadius: 6, padding: "9px 14px", fontSize: 13, cursor: "pointer", fontFamily: F.body },
  btnGhostActive: { borderColor: T.danger, color: T.danger },

  avisoOk: { display: "flex", alignItems: "center", gap: 6, color: T.green, fontSize: 13, marginTop: 8 },

  tableWrap: { overflowX: "auto", marginTop: 8 },
  table: { width: "100%", borderCollapse: "collapse", fontSize: 13 },
  th: { textAlign: "left", color: T.muted, fontWeight: 600, fontSize: 11, letterSpacing: 0.5, textTransform: "uppercase", padding: "8px 8px", borderBottom: `1px solid ${T.border}` },
  td: { padding: "6px 8px", borderBottom: `1px solid ${T.border}` },
  tdNum: { padding: "6px 8px", borderBottom: `1px solid ${T.border}`, color: T.muted, fontFamily: F.mono, fontSize: 12 },
  tdCenter: { padding: "6px 8px", borderBottom: `1px solid ${T.border}`, textAlign: "center" },
  tdMono: { padding: "6px 8px", borderBottom: `1px solid ${T.border}`, fontFamily: F.mono, textAlign: "right" },
  tdInput: { width: "100%", background: "transparent", border: "none", color: T.text, fontSize: 13, fontFamily: F.body, outline: "none" },
  tdInputNum: { width: 70, background: T.panelAlt, border: `1px solid ${T.border}`, borderRadius: 4, color: T.text, fontFamily: F.mono, fontSize: 13, padding: "4px 6px", outline: "none", textAlign: "right" },
  tdInputLearned: { borderColor: T.amber, color: T.amber },
  emptyRow: { padding: "18px 8px", color: T.muted, textAlign: "center", fontSize: 13 },

  totalsBox: { marginTop: 14, marginLeft: "auto", width: 260, display: "flex", flexDirection: "column", gap: 6 },
  totalsRow: { display: "flex", justifyContent: "space-between", fontSize: 13, color: T.muted },
  totalsFinal: { color: T.text, fontWeight: 700, fontSize: 16, borderTop: `1px solid ${T.border}`, paddingTop: 8, marginTop: 4 },
  mono: { fontFamily: F.mono },
  footNote: { display: "flex", alignItems: "center", gap: 6, marginTop: 20, fontSize: 11, color: T.muted, lineHeight: 1.5 },
};
